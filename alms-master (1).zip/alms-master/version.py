

#python -c "import IPython; print(IPython.__version__)"

#from dotenv import load_deotnv
#load_dotenv()

# scipy

# import scipy
#
# print('scipy: %s' % scipy.__version__)

# numpy

import numpy

print('numpy: %s' % numpy.__version__)

# matplotlib

# import matplotlib
#
# print('matplotlib: %s' % matplotlib.__version__)

# pandas

# import pandas
#
# print('pandas: %s' % pandas.__version__)

# statsmodels

# import statsmodels

# print('statsmodels: %s' % statsmodels.__version__)
#
# # scikit-learn
#
# import sklearn

# print('sklearn: %s' % sklearn.__version__)


# import cv2 as cv
#
# print('cv2: %s' % cv.__version__)

import torch

print('torch: %s' % torch.__version__)

import torchvision

print('torchvision: %s' % torchvision.__version__)

print('cuda:', torch.cuda.is_available())

print('cuda count:', torch.cuda.device_count())

print("aadb{}".format(4))