## ALMS
资产台账系统‌
Asset Lifecycle Management System，简写ALM或者ALMS